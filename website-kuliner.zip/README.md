# KulinerKita - Website Platform Jual Beli Makanan

Website landing page interaktif & modern untuk platform jual beli makanan yang dapat di-host dengan mudah menggunakan GitHub Pages.

## Fitur Utama:
- Design modern & responsif (Tailwind CSS)
- Katalog menu makanan & minuman
- Filter & pencarian menu
- Pemesanan langsung terintegrasi dengan WhatsApp
- Tombol pendaftaran mitra usaha kuliner

## Cara Menggunakan:
1. Extract file `website-kuliner.zip` ini.
2. Buat repositori baru di GitHub.
3. Upload file `index.html` ke repositori tersebut.
4. Aktifkan **GitHub Pages** di menu **Settings -> Pages**.
